package com.cognizant.Airport.Dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.cognizant.Airport.Model.LoginDetails;
import com.cognizant.Airport.Model.ManagerDetails;
import com.cognizant.Airport.Service.IManagerDetailsService;

@Repository
public class ManagerDao implements IManagerDetailsService {
	@PersistenceContext
	public EntityManager entityManager;
	

	@Override
	public ManagerDetails saveManagerDetails(ManagerDetails managerDetails) {

		ManagerDetails managerDetail=entityManager.merge(managerDetails);
		return managerDetail;

	}

	@Override
	public String managerLogin(LoginDetails loginDetails) {
		ManagerDetails managerDetails = entityManager.find(ManagerDetails.class,LoginDetails.getUserId());
		//.println(managerDetails);
		if(managerDetails!=null) {
			if(managerDetails.getStatus()==0) { //.println("Account Not Activated.");	return "Account Not Activated.";
				
			}
			
		if(managerDetails.getPassword().equals(LoginDetails.getPassword())) {
			//.println(managerDetails.toString());
			return "success";
		}
		else {
			//.println("Wrong Password");
			return ("Wrong Password");
		}}
		
		else {
			//.println("Wrong UserId");
		return "Wrong UserId";
		}
	}
	
	@Override
	public ManagerDetails getManagerDetails(int i) {
		// TODO Auto-generated method stub
		return entityManager.find(ManagerDetails.class,i);
	}
}
