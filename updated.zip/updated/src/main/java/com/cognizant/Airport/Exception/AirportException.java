package com.cognizant.Airport.Exception;

public class AirportException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public String airportException() {
		return "Error Occured Please Login again.";
	}
	
}
